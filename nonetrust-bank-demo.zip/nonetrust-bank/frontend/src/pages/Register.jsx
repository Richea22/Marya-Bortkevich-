import { Link } from "react-router-dom";

export default function Register() {
  return (
    <main className="center-page">
      <div className="form-card">
        <h1>Create Account</h1>
        <p>Register for the NoneTrust Bank demo.</p>
        <label>Full name</label>
        <input type="text" placeholder="Your name" />
        <label>Email</label>
        <input type="email" placeholder="you@example.com" />
        <label>Password</label>
        <input type="password" placeholder="Create a password" />
        <button>Create Account</button>
        <small>Demo only. Do not enter real financial or sensitive information.</small>
        <p><Link to="/login">Already have an account? Sign in</Link></p>
      </div>
    </main>
  );
}
