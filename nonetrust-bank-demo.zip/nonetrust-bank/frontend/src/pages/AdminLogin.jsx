import { Link } from "react-router-dom";

export default function AdminLogin() {
  return (
    <main className="center-page">
      <div className="form-card">
        <h1>Administrator Portal</h1>
        <p>NoneTrust Bank Demo</p>
        <label>Admin email</label>
        <input type="email" placeholder="admin@example.com" />
        <label>Password</label>
        <input type="password" placeholder="Password" />
        <button>Sign In</button>
        <small>Demo interface only. Real admin authentication is not yet connected.</small>
        <p><Link to="/">← Back to home</Link></p>
      </div>
    </main>
  );
}
