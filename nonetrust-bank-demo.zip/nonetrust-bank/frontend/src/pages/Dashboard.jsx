import { Link } from "react-router-dom";

export default function Dashboard() {
  return (
    <main className="dashboard">
      <h1>Customer Dashboard</h1>
      <p>Welcome to the NoneTrust Bank demo.</p>
      <div className="dashboard-grid">
        <div className="dashboard-card"><h3>Demo Balance</h3><h2>$5,000.00</h2></div>
        <div className="dashboard-card"><h3>Account Status</h3><p>Demo Active</p></div>
        <div className="dashboard-card"><h3>Transactions</h3><Link to="/transactions">View history</Link></div>
      </div>
    </main>
  );
}
