import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      <nav className="navbar">
        <div className="brand">🔷 NoneTrust Bank</div>
        <div className="nav-links">
          <Link to="/login">Login</Link>
          <Link to="/register" className="button">Create Account</Link>
        </div>
      </nav>

      <main className="hero">
        <section>
          <p className="eyebrow">DIGITAL BANKING DEMO</p>
          <h1>Simple, secure digital banking.</h1>
          <p>Explore the NoneTrust Bank demo platform with a modern customer experience.</p>
          <div className="hero-buttons">
            <Link to="/register" className="button">Get Started</Link>
            <Link to="/login" className="secondary-button">Sign In</Link>
          </div>
        </section>

        <section className="balance-card">
          <span>Demo Available Balance</span>
          <h2>$5,000.00</h2>
          <p>**** **** **** 4589</p>
        </section>
      </main>

      <footer>© 2026 NoneTrust Bank Demo</footer>
    </div>
  );
}
