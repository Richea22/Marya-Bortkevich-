import { Link } from "react-router-dom";

export default function Transactions() {
  return (
    <main className="dashboard">
      <h1>Transactions</h1>
      <div className="dashboard-card">
        <p>No real transactions. This is demo data only.</p>
        <p>Demo deposit — $2,000.00</p>
        <p>Demo transfer — $500.00</p>
      </div>
      <p><Link to="/dashboard">← Back to dashboard</Link></p>
    </main>
  );
}
