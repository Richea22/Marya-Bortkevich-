import { Link } from "react-router-dom";

export default function Login() {
  return (
    <main className="center-page">
      <div className="form-card">
        <h1>Sign In</h1>
        <p>NoneTrust Bank Demo</p>
        <label>Email</label>
        <input type="email" placeholder="you@example.com" />
        <label>Password</label>
        <input type="password" placeholder="Password" />
        <button>Sign In</button>
        <small>Demo only. Backend authentication will be connected in the next stage.</small>
        <p><Link to="/register">Create an account</Link></p>
        <p><Link to="/">← Back to home</Link></p>
      </div>
    </main>
  );
}
