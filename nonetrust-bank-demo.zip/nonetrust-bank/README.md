# NoneTrust Bank Demo

A fictional/demo full-stack banking application starter project.

## Structure

- `frontend/` — React + Vite demo interface
- `backend/` — Node.js + Express API starter

## Important

This project is a demo and does not process real money or provide real banking services.

Do not commit `.env` files, passwords, API keys, database credentials, or other secrets to GitHub.

## Frontend

```bash
cd frontend
npm install
npm run dev
```

## Backend

```bash
cd backend
npm install
npm start
```
